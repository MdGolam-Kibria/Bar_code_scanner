# NID Scanner
**NID Scanner** is a barcode scanner, which specifically scans national identity card of Bangladesh (Old and New Smart Card) and read it's content.

This app also stores your scanned reports. So you can check all the previous scanned reports later.

## Features
* Read national identity card of Bangladesh
* History of past scanned report
* Delete History
* Little bip sound to indicate a successful scan
* Redline to guide barcode position correctly
* Volume down button to turn on flash

